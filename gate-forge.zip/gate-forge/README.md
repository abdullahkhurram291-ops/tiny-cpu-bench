# Gate Forge

**A puzzle game where you build a computer's adder from nothing but NAND gates.**

![Tests](https://github.com/YOUR-USERNAME/gate-forge/actions/workflows/tests.yml/badge.svg)
&nbsp;·&nbsp; Written in Python, standard library only, no installs needed
&nbsp;·&nbsp; Companion to [Tiny CPU Bench](https://github.com/YOUR-USERNAME/tiny-cpu-bench)

```
Level 4 · XOR · Different
XOR (exclusive or) outputs 1 when the inputs are different.

Parts:   NAND(a, b), NOT(a), AND(a, b), OR(a, b)
Target:  4 NAND gates for a star

> n = NAND(a, b)
> x = NAND(a, n)
> y = NAND(b, n)
> out = NAND(x, y)
> :test
  a b │ out
  ─────────
  0 0 │   0  ✓
  0 1 │   1  ✓
  1 0 │   1  ✓
  1 1 │   0  ✓

✓ Solved! Your XOR uses 4 NAND gates. ★ You hit the target!
XOR is now a part you can use in later levels.
```

## The problem

Every computer is built from logic gates, and every gate can be built from one kind: NAND. Textbooks state this, but it's hard to *believe* until you do it yourself.

Gate Forge makes you do it. You start with only NAND. Each level asks you to build a new part, and **every part you build becomes available in the next level**. Eight levels later you have a 4-bit adder, the circuit at the heart of a CPU's arithmetic unit, made entirely from your own work.

## The levels

| # | Build | What it does | Target |
| --- | --- | --- | --- |
| 1 | NOT | flips a bit | 1 NAND |
| 2 | AND | 1 only if both inputs are 1 | 2 |
| 3 | OR | 1 if either input is 1 | 3 |
| 4 | XOR | 1 if the inputs differ | 4 |
| 5 | MUX | picks input a or b using sel | 4 |
| 6 | HALFADD | adds two bits → sum, carry | 5 |
| 7 | FULLADD | adds three bits (with carry in) | 9 |
| 8 | ADD4 | adds two 4-bit numbers | 32 |

Every solution that matches the goal passes. Using no more NAND gates than the target earns a ★. Because later parts are built from *your* earlier parts, a wasteful XOR makes your adder bigger too.

## How to play

**1. Install Python 3.10 or newer** from [python.org](https://www.python.org/downloads/). On Windows, tick "Add python.exe to PATH" during installation.

**2. Download this project** (green **Code** button → **Download ZIP**, then unzip) or clone it:

```bash
git clone https://github.com/YOUR-USERNAME/gate-forge.git
```

**3. Open a terminal in the `gate-forge` folder and start the game:**

```bash
python -m gate_forge        # Windows: py -m gate_forge   ·   macOS/Linux: python3 -m gate_forge
```

Your progress is saved automatically in `~/.gate_forge/save.json`.

### Writing a circuit

Type one line per part:

```
n = NAND(a, b)          # a gate whose output wire is called n
out = NAND(n, n)        # use wires you made earlier
s, c = HALFADD(a, b)    # parts with two outputs need two names
x = a                   # a plain wire
y = NAND(a, 1)          # 0 and 1 can be used as fixed inputs
```

Lines can be in any order. Part names can be lower or upper case. Anything after `#` is a comment.

### Commands inside a level

| Command | Does |
| --- | --- |
| `:test` | check your circuit against every row of the goal |
| `:show` | list your lines with numbers |
| `:undo` / `:del N` / `:clear` | remove the last line / line N / everything |
| `:hint` | get a hint |
| `:goal` | show the goal again |
| `:load FILE` | load lines from a text file |
| `:back` / `:quit` | back to the menu / leave |

### Other commands

```bash
python -m gate_forge levels                 # your progress
python -m gate_forge check 4 my_xor.txt     # check a solution written in VS Code or any editor
python -m gate_forge sandbox examples/majority.txt   # truth table of any circuit
python -m gate_forge reset --yes            # start over
```

The **sandbox** lets you build anything with NAND and the parts you've unlocked. Any name you use but never define becomes an input, and any wire nothing else uses becomes an output.

## How it works

```
gate_forge/
  circuit.py    reads circuit text, checks it, and computes outputs
  levels.py     the eight levels: goals, hints, lessons
  progress.py   checks solutions against a level, saves progress
  game.py       the terminal game and the command-line commands
tests/
  test_circuit.py, test_levels.py   47 tests (unittest)
  solutions/    reference solutions for every level (spoilers!)
examples/       circuits to try in the sandbox
```

**1. Reading a circuit.** `parse_line()` uses regular expressions to split a line like `s, c = HALFADD(a, b)` into its output names, part name and input names. Mistakes get a plain-English message with the line number, for example *"'a b' looks like two names. Did you forget a comma?"*.

**2. Checking it.** `Circuit` checks that every part exists and is unlocked, gets the right number of wires, that every wire is defined exactly once, and that there are **no loops**. Loops are found with a depth-first search that marks each wire as *visiting* or *done*. Reaching a *visiting* wire again means it depends on itself (`x -> y -> x`).

**3. Computing outputs, with recursion.** To find a wire's value, `value_of()` first finds the values of the wires feeding it, by calling itself, then applies the part. Results are remembered, so each gate is only computed once. Because loops were already rejected, the recursion always finishes.

**4. Circuits become parts.** When you solve a level, `Circuit.as_part()` wraps your circuit in a `Part` object with the same interface as NAND: a name, input names, output names, a NAND count and a `run()` function. Later circuits can't tell the difference between NAND and your parts, so the same code evaluates a single gate and a 4-bit adder made of 32 gates.

**5. Checking against the goal.** Each level has a `goal` function written in ordinary Python (for example `lambda a, b: (a ^ b,)`). The checker tries every input combination (2⁸ = 256 rows for the 4-bit adder) and compares your circuit's outputs with the goal's.

## Run the tests

```bash
python -m unittest          # no installs needed
```

They also run automatically on GitHub for Python 3.10–3.13 on Linux and Windows (`.github/workflows/tests.yml`).

## Roadmap

- [ ] More levels: 4-bit comparator, a 1-bit ALU that can AND or ADD, a register built from latches
- [ ] Show 4-bit numbers as decimals in error messages (e.g. "7 + 5 should be 12, you got 8")
- [ ] Arabic translation
- [ ] A graphical version with drag-and-drop gates (tkinter or Pygame)
- [ ] Ideas from testers

## How this project was built

Version 1.0 was generated with an AI assistant (Claude, by Anthropic) at my request. [CONTRIBUTION.md](CONTRIBUTION.md) records exactly which parts I wrote myself, what I changed, and what I learned.

## License

MIT, see [LICENSE](LICENSE).
