# Changelog

## 1.0.0

- Circuit engine: text circuits, checking with line-numbered errors, loop detection, recursive evaluation, solved circuits become parts, NAND counting.
- Eight levels from NOT to a 4-bit ripple-carry adder, with hints, lessons and star targets.
- Terminal game with saving, plus `check`, `sandbox`, `levels` and `reset` commands.
- 47 tests, run on Linux and Windows by GitHub Actions.

### Found in play-testing and fixed before release

| Problem | Fix |
| --- | --- |
| Typing `NAND(a a)` gave a confusing "not a wire name" error. | It now asks "Did you forget a comma?" |
| Level 1 said "Target: 1 NAND gates". | Singular and plural are handled. |
| Symbols like ✓ and ★ could crash the game in older Windows terminals. | The game checks what the terminal can show and falls back to plain text (`ok`, `X`, `*`). |
| Piping output into another command (`... levels \| head`) printed an error. | It now exits quietly. |

<!-- Add a section above this line for each new version, e.g. "## 1.1.0 — comparator level". -->
