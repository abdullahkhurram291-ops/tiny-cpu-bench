import sys

from .game import main

try:
    sys.exit(main())
except BrokenPipeError:  # output was cut off, e.g. piped into `head`
    sys.exit(0)
