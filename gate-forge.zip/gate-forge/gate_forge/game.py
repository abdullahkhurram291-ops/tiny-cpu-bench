"""The terminal game, and the command-line commands (play, check, sandbox, levels, reset)."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Callable, List, Optional, Sequence, TextIO

from . import __version__
from .circuit import NAND, Circuit, CircuitError, parse_line
from .levels import LEVELS, Level, find_level, goal_table
from .progress import CheckResult, Progress, available_parts

CPU_BENCH_NOTE = "See it run real programs in Tiny CPU Bench: https://github.com/YOUR-USERNAME/tiny-cpu-bench"


# --------------------------------------------------------------------------- output helpers


class Style:
    """Colours and symbols that fall back to plain text where the terminal can't show them."""

    def __init__(self, out: TextIO):
        self.color = hasattr(out, "isatty") and out.isatty() and "NO_COLOR" not in os.environ
        if self.color and os.name == "nt":
            os.system("")  # turns on colour codes in the Windows terminal
        enc = getattr(out, "encoding", None) or "ascii"
        try:
            "✓✗★─·".encode(enc)
            self.ok, self.bad, self.star, self.line, self.dot = "✓", "✗", "★", "─", "·"
        except (UnicodeEncodeError, LookupError):
            self.ok, self.bad, self.star, self.line, self.dot = "ok", "X", "*", "-", "-"

    def _wrap(self, code: str, text: str) -> str:
        return f"\033[{code}m{text}\033[0m" if self.color else text

    def bold(self, t): return self._wrap("1", t)
    def dim(self, t): return self._wrap("2", t)
    def green(self, t): return self._wrap("32", t)
    def red(self, t): return self._wrap("31", t)
    def yellow(self, t): return self._wrap("33", t)


def format_table(inputs, outputs, rows, style: Style, marks=None) -> List[str]:
    """rows: list of (input bits, output bits). marks: optional list of True/False per row."""
    widths_in = [max(len(n), 1) for n in inputs]
    widths_out = [max(len(n), 1) for n in outputs]
    sep = " │ " if style.line == "─" else " | "
    head = " ".join(n.rjust(w) for n, w in zip(inputs, widths_in)) + sep + " ".join(
        n.rjust(w) for n, w in zip(outputs, widths_out))
    lines = [style.bold(head), style.dim(style.line * len(head))]
    for i, (bits_in, bits_out) in enumerate(rows):
        text = " ".join(str(b).rjust(w) for b, w in zip(bits_in, widths_in)) + sep + " ".join(
            str(b).rjust(w) for b, w in zip(bits_out, widths_out))
        if marks is not None:
            text += "  " + (style.green(style.ok) if marks[i] else style.red(style.bad))
        lines.append(text)
    return lines


# --------------------------------------------------------------------------- the game


class Game:
    def __init__(self, progress: Progress, input_fn: Callable[[str], str] = input, out: TextIO = sys.stdout):
        self.progress = progress
        self.input = input_fn
        self.out = out
        self.s = Style(out)

    def say(self, text: str = "") -> None:
        print(text, file=self.out)

    def ask(self, prompt: str) -> Optional[str]:
        try:
            return self.input(prompt)
        except (EOFError, KeyboardInterrupt):
            self.say()
            return None

    # ---------------------------------------------------------------- menu

    def level_status(self, lv: Level) -> str:
        s = self.s
        if self.progress.is_solved(lv):
            n = self.progress.counts[lv.part_name]
            star = " " + s.yellow(s.star) if n <= lv.target else ""
            return s.green(f"{s.ok} solved") + f" {s.dot} {n} NAND (target {lv.target}){star}"
        if self.progress.is_open(lv):
            return s.bold("open")
        return s.dim("locked")

    def show_levels(self) -> None:
        self.say(self.s.bold("Levels"))
        for lv in LEVELS:
            self.say(f"  {lv.number}. {lv.part_name:<8} {lv.title:<16} {self.level_status(lv)}")

    def next_open_level(self) -> Optional[Level]:
        for lv in LEVELS:
            if not self.progress.is_solved(lv):
                return lv
        return None

    def run(self) -> None:
        s = self.s
        self.say(s.bold("GATE FORGE") + f" {s.dot} build a computer from a single kind of gate")
        self.say(s.dim("Type a level number to play it, or q to quit."))
        while True:
            self.say()
            self.show_levels()
            nxt = self.next_open_level()
            default = str(nxt.number) if nxt else ""
            answer = self.ask(f"\nLevel{f' [{default}]' if default else ''}: ")
            if answer is None:
                return
            answer = answer.strip() or default
            if answer.lower() in ("q", "quit", "exit"):
                return
            if not answer:
                self.say("You've solved every level. Pick one to improve your score, or q to quit.")
                continue
            try:
                lv = find_level(answer)
            except KeyError as e:
                self.say(s.red(str(e.args[0])))
                continue
            if not self.progress.is_open(lv):
                self.say(s.red(f"Level {lv.number} is locked. Solve level {lv.number - 1} first."))
                continue
            if self.play_level(lv) == "quit":
                return

    # ---------------------------------------------------------------- a level

    def show_intro(self, lv: Level) -> None:
        s = self.s
        parts, _ = available_parts(lv, self.progress.unlocked)
        self.say()
        self.say(s.bold(f"Level {lv.number} {s.dot} {lv.part_name} {s.dot} {lv.title}"))
        self.say(lv.story)
        self.say()
        self.say(f"Inputs:  {', '.join(lv.inputs)}")
        self.say(f"Outputs: {', '.join(lv.outputs)}")
        part_list = ", ".join(p.name + "(" + ", ".join(p.inputs) + ")" for p in parts.values())
        self.say(f"Parts:   {part_list}")
        self.say(f"Target:  {lv.target} NAND gate{'s' if lv.target != 1 else ''} for a star")
        self.say()
        self.show_goal(lv)
        self.say()
        self.say(s.dim(f"Type one line at a time, e.g.  n = NAND(a, b)   {s.dot}   :help for commands"))

    def show_goal(self, lv: Level) -> None:
        rows = goal_table(lv)
        self.say(self.s.bold("Goal"))
        if lv.goal_summary:
            self.say(lv.goal_summary)
            self.say(self.s.dim(f"First 6 of {len(rows)} rows:"))
            rows = rows[:3] + rows[-3:]
        for line in format_table(lv.inputs, lv.outputs, rows, self.s):
            self.say("  " + line)

    def show_lines(self, lines: List[str]) -> None:
        if not lines:
            self.say(self.s.dim("(no lines yet)"))
        for i, text in enumerate(lines, start=1):
            self.say(f"  {self.s.dim(str(i).rjust(2))}  {text}")

    def show_result(self, r: CheckResult) -> None:
        s = self.s
        if r.error:
            self.say(s.red(f"{s.bad} {r.error}"))
            return
        lv = r.level
        rows = r.rows
        if len(rows) > 16:
            wrong = r.wrong_rows
            if wrong:
                self.say(s.red(f"{len(wrong)} of {len(rows)} rows are wrong. The first few:"))
                rows = wrong[:8]
            else:
                rows = []
        if rows:
            marks = [exp == act for _, exp, act in rows]
            table = [(bits, act) for bits, _, act in rows]
            for line in format_table(lv.inputs, lv.outputs, table, s, marks):
                self.say("  " + line)
        if not r.passed:
            first = r.wrong_rows[0]
            got = ", ".join(f"{n}={v}" for n, v in zip(lv.outputs, first[2]))
            want = ", ".join(f"{n}={v}" for n, v in zip(lv.outputs, first[1]))
            when = ", ".join(f"{n}={v}" for n, v in zip(lv.inputs, first[0]))
            self.say(s.red(f"{s.bad} When {when}, your circuit gives {got} but it should give {want}."))

    def play_level(self, lv: Level) -> str:
        s = self.s
        saved = self.progress.solutions.get(lv.part_name)
        lines: List[str] = [l for l in saved.splitlines() if l.strip()] if saved else []
        self.show_intro(lv)
        if lines:
            self.say(s.dim("Your saved solution is loaded:"))
            self.show_lines(lines)

        while True:
            raw = self.ask("> ")
            if raw is None:
                return "quit"
            text = raw.strip()
            if not text:
                continue

            if text.startswith(":"):
                cmd, _, arg = text[1:].partition(" ")
                cmd = cmd.lower()
                if cmd in ("q", "quit", "exit"):
                    return "quit"
                if cmd in ("b", "back", "menu"):
                    return "back"
                if cmd in ("h", "help", "?"):
                    self.say(HELP)
                elif cmd in ("t", "test", "run"):
                    r = self.progress.record(lv, "\n".join(lines))
                    self.show_result(r)
                    if r.passed:
                        self.celebrate(r)
                        return "back"
                elif cmd in ("s", "show", "list"):
                    self.show_lines(lines)
                elif cmd == "undo":
                    if lines:
                        self.say(s.dim(f"Removed: {lines.pop()}"))
                    else:
                        self.say("Nothing to undo.")
                elif cmd in ("del", "delete"):
                    try:
                        removed = lines.pop(int(arg) - 1)
                        self.say(s.dim(f"Removed line {arg}: {removed}"))
                    except (ValueError, IndexError):
                        self.say(s.red("Give a line number from :show, e.g.  :del 2"))
                elif cmd == "clear":
                    lines.clear()
                    self.say(s.dim("All lines removed."))
                elif cmd == "hint":
                    self.say(s.yellow(lv.hint))
                elif cmd == "goal":
                    self.show_goal(lv)
                elif cmd == "load":
                    loaded = self.load_file(arg)
                    if loaded is not None:
                        lines = loaded
                        self.show_lines(lines)
                else:
                    self.say(s.red(f"Unknown command :{cmd}. Type :help to see the commands."))
                continue

            # A circuit line: check its spelling now, check the whole circuit on :test.
            try:
                if parse_line(text) is None:
                    continue
            except CircuitError as e:
                self.say(s.red(f"{s.bad} {e.message}"))
                continue
            lines.append(text)

    def load_file(self, name: str) -> Optional[List[str]]:
        if not name.strip():
            self.say(self.s.red("Give a file name, e.g.  :load my_xor.txt"))
            return None
        try:
            text = Path(name.strip()).read_text(encoding="utf-8")
        except OSError as e:
            self.say(self.s.red(f"Couldn't open {name.strip()}: {e.strerror}"))
            return None
        return [l.rstrip() for l in text.splitlines() if l.split("#", 1)[0].strip()]

    def celebrate(self, r: CheckResult) -> None:
        s = self.s
        lv = r.level
        star = s.yellow(f" {s.star} You hit the target!") if r.star else s.dim(f" (target: {lv.target}, try again for a star)")
        self.say()
        self.say(s.green(s.bold(f"{s.ok} Solved! Your {lv.part_name} uses {r.nand_count} NAND gate{'s' if r.nand_count != 1 else ''}.")) + star)
        self.say(lv.lesson)
        if lv.number < len(LEVELS):
            self.say(s.bold(f"{lv.part_name} is now a part you can use in later levels."))
        else:
            self.say()
            self.say(s.bold("You built a computer's adder from a single kind of gate."))
            self.say(CPU_BENCH_NOTE)


HELP = """Commands
  :test         check your circuit against the goal
  :show         list your lines with numbers
  :undo         remove the last line
  :del N        remove line N
  :clear        remove every line
  :hint         get a hint
  :goal         show the goal again
  :load FILE    load lines from a text file
  :back         back to the level list
  :quit         leave the game (progress is saved when you solve a level)

Writing a circuit
  n = NAND(a, b)        a gate: its output wire is called n
  out = NAND(n, n)      use wires you made earlier
  s, c = HALFADD(a, b)  parts with two outputs need two names
  x = a                 a plain wire
  0 and 1 can be used as fixed inputs. Anything after # is a comment."""


# --------------------------------------------------------------------------- command line


def cmd_check(progress: Progress, level_key: str, file: str, out: TextIO) -> int:
    s = Style(out)
    try:
        lv = find_level(level_key)
    except KeyError as e:
        print(s.red(e.args[0]), file=out)
        return 2
    if not progress.is_open(lv):
        print(s.red(f"Level {lv.number} is locked. Solve level {lv.number - 1} first."), file=out)
        return 1
    try:
        source = Path(file).read_text(encoding="utf-8")
    except OSError as e:
        print(s.red(f"Couldn't open {file}: {e.strerror}"), file=out)
        return 2
    game = Game(progress, out=out)
    r = progress.record(lv, source)
    print(s.bold(f"Level {lv.number} {s.dot} {lv.part_name}"), file=out)
    game.show_result(r)
    if r.passed:
        game.celebrate(r)
        return 0
    return 1


def cmd_sandbox(progress: Progress, file: str, out: TextIO) -> int:
    """Prints the truth table of any circuit, using NAND and every part you've unlocked."""
    s = Style(out)
    try:
        source = Path(file).read_text(encoding="utf-8")
    except OSError as e:
        print(s.red(f"Couldn't open {file}: {e.strerror}"), file=out)
        return 2
    parts = {"NAND": NAND, **progress.unlocked}
    locked = {lv.part_name: f"{lv.part_name} is locked. Solve level {lv.number} to unlock it"
              for lv in LEVELS if lv.part_name not in parts}
    try:
        c = Circuit(source, parts, locked=locked)
    except CircuitError as e:
        print(s.red(f"{s.bad} {e}"), file=out)
        return 1
    print(s.bold(f"Inputs: {', '.join(c.inputs) or '(none)'}   Outputs: {', '.join(c.outputs)}   "
                 f"NAND gates: {c.nand_count}"), file=out)
    for line in format_table(c.inputs, c.outputs, c.truth_table(), s):
        print("  " + line, file=out)
    return 0


def main(argv: Optional[Sequence[str]] = None, out: TextIO = sys.stdout,
         input_fn: Callable[[str], str] = input) -> int:
    parser = argparse.ArgumentParser(
        prog="gate_forge",
        description="Gate Forge: build a computer's adder from nothing but NAND gates.")
    parser.add_argument("--version", action="version", version=f"Gate Forge {__version__}")
    parser.add_argument("--save", help="save file to use (default: ~/.gate_forge/save.json)")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("play", help="play the game (the default)")
    sub.add_parser("levels", help="list levels and your progress")
    p_check = sub.add_parser("check", help="check a solution written in a text file")
    p_check.add_argument("level", help="level number or part name, e.g. 4 or XOR")
    p_check.add_argument("file", help="text file with your circuit")
    p_sand = sub.add_parser("sandbox", help="print the truth table of any circuit file")
    p_sand.add_argument("file")
    p_reset = sub.add_parser("reset", help="delete all progress")
    p_reset.add_argument("--yes", action="store_true", help="confirm deleting progress")
    args = parser.parse_args(argv)
    try:
        out.reconfigure(errors="replace")  # never crash on a symbol an old terminal can't show
    except (AttributeError, ValueError):
        pass

    progress = Progress(Path(args.save) if args.save else None)

    if args.command == "levels":
        Game(progress, out=out).show_levels()
        return 0
    if args.command == "check":
        return cmd_check(progress, args.level, args.file, out)
    if args.command == "sandbox":
        return cmd_sandbox(progress, args.file, out)
    if args.command == "reset":
        if not args.yes:
            print("This deletes all your solutions. Run again with --yes to confirm:  python -m gate_forge reset --yes",
                  file=out)
            return 1
        progress.reset()
        print("Progress deleted.", file=out)
        return 0
    Game(progress, input_fn=input_fn, out=out).run()
    return 0
