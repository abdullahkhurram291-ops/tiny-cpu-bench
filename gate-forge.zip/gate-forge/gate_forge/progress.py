"""Checking solutions against a level, and saving the player's progress."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .circuit import NAND, Bits, Circuit, CircuitError, Part
from .levels import LEVELS, Level, goal_table

SAVE_VERSION = 1


# --------------------------------------------------------------------------- checking


@dataclass
class CheckResult:
    level: Level
    error: Optional[CircuitError] = None
    rows: List[Tuple[Bits, Bits, Bits]] = field(default_factory=list)  # (inputs, expected, actual)
    nand_count: int = 0
    circuit: Optional[Circuit] = None

    @property
    def wrong_rows(self):
        return [r for r in self.rows if r[1] != r[2]]

    @property
    def passed(self) -> bool:
        return self.error is None and not self.wrong_rows

    @property
    def star(self) -> bool:
        return self.passed and self.nand_count <= self.level.target


def available_parts(level: Level, unlocked: Dict[str, Part]) -> Tuple[Dict[str, Part], Dict[str, str]]:
    """Parts usable in this level, plus messages for parts that aren't usable yet."""
    parts = {"NAND": NAND}
    locked = {}
    for lv in LEVELS:
        if lv.number < level.number and lv.part_name in unlocked:
            parts[lv.part_name] = unlocked[lv.part_name]
        elif lv.number == level.number:
            locked[lv.part_name] = f"you're building {lv.part_name} in this level, so you can't use it yet"
        else:
            locked[lv.part_name] = f"{lv.part_name} is locked. Solve level {lv.number} to unlock it"
    return parts, locked


def check(level: Level, source: str, unlocked: Dict[str, Part]) -> CheckResult:
    """Builds the player's circuit and compares it with the goal for every input combination."""
    parts, locked = available_parts(level, unlocked)
    result = CheckResult(level)
    try:
        circuit = Circuit(source, parts, level.inputs, level.outputs, locked)
        result.circuit = circuit
        result.nand_count = circuit.nand_count
        for bits, expected in goal_table(level):
            result.rows.append((bits, expected, circuit.run_bits(bits)))
    except CircuitError as e:
        result.error = e
    return result


# --------------------------------------------------------------------------- saving


def default_save_path() -> Path:
    custom = os.environ.get("GATE_FORGE_SAVE")
    return Path(custom) if custom else Path.home() / ".gate_forge" / "save.json"


class Progress:
    """Which levels are solved. Stores the player's own circuit text for each one."""

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else default_save_path()
        self.solutions: Dict[str, str] = {}
        self.unlocked: Dict[str, Part] = {}
        self.counts: Dict[str, int] = {}
        self.load()

    def load(self) -> None:
        self.solutions = {}
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                self.solutions = {k: v for k, v in data.get("solutions", {}).items() if isinstance(v, str)}
            except (OSError, ValueError, AttributeError):
                self.solutions = {}  # a damaged save file just means starting fresh
        self._rebuild()

    def _rebuild(self) -> None:
        """Turns saved solutions back into parts, in level order. Stops at the first gap."""
        self.unlocked, self.counts = {}, {}
        for lv in LEVELS:
            src = self.solutions.get(lv.part_name)
            if src is None:
                break
            r = check(lv, src, self.unlocked)
            if not r.passed:
                break
            self.unlocked[lv.part_name] = r.circuit.as_part(lv.part_name)
            self.counts[lv.part_name] = r.nand_count

    def is_solved(self, level: Level) -> bool:
        return level.part_name in self.unlocked

    def is_open(self, level: Level) -> bool:
        return level.number == 1 or self.is_solved(LEVELS[level.number - 2])

    def record(self, level: Level, source: str) -> CheckResult:
        """Checks a solution and saves it if it passes."""
        r = check(level, source, self.unlocked)
        if r.passed:
            self.solutions[level.part_name] = source.strip() + "\n"
            self._rebuild()
            self.save()
        return r

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {"version": SAVE_VERSION, "solutions": self.solutions}
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def reset(self) -> None:
        self.solutions = {}
        self._rebuild()
        if self.path.exists():
            self.path.unlink()
