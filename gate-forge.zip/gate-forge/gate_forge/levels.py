"""The levels. Each one asks you to build a part, and the part you build is unlocked for later levels."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Tuple

from .circuit import Bits


@dataclass(frozen=True)
class Level:
    number: int
    part_name: str          # the part you build, and the name it gets once unlocked
    title: str
    story: str
    inputs: Tuple[str, ...]
    outputs: Tuple[str, ...]
    goal: Callable[..., Bits]   # takes the input bits, returns the correct output bits
    target: int             # NAND count of our reference solution: match it to earn a star
    hint: str
    lesson: str             # shown after you solve it
    goal_summary: str = ""  # for big tables that are too long to print


def _add4(a3, a2, a1, a0, b3, b2, b1, b0):
    total = (a3 * 8 + a2 * 4 + a1 * 2 + a0) + (b3 * 8 + b2 * 4 + b1 * 2 + b0)
    return ((total >> 3) & 1, (total >> 2) & 1, (total >> 1) & 1, total & 1, total >> 4)


LEVELS: Tuple[Level, ...] = (
    Level(
        1, "NOT", "Flip it",
        "All you have is one kind of gate: NAND. It outputs 0 only when both inputs are 1.\n"
        "Build NOT, which flips its input: 0 becomes 1 and 1 becomes 0.",
        ("a",), ("out",), lambda a: (1 - a,), 1,
        "What does NAND do if you connect the same wire to both of its inputs?",
        "NAND(a, a) is 0 only when a is 1, so it flips a. One gate, and you already have a new part.",
    ),
    Level(
        2, "AND", "Both at once",
        "AND outputs 1 only when both inputs are 1. It is exactly the opposite of NAND.",
        ("a", "b"), ("out",), lambda a, b: (a & b,), 2,
        "You built an 'opposite' part in level 1. What happens if you put it after a NAND?",
        "NAND means 'not AND', so NOT(NAND(a, b)) is AND. Inside a CPU, AND is used to switch a signal on or off.",
    ),
    Level(
        3, "OR", "Either one",
        "OR outputs 1 when at least one input is 1.",
        ("a", "b"), ("out",), lambda a, b: (a | b,), 3,
        "OR is 0 only when both inputs are 0. Try flipping both inputs first, then feeding them into a NAND.",
        "NAND(NOT a, NOT b) is OR. This trick is called De Morgan's law, and it lets one gate type build every other.",
    ),
    Level(
        4, "XOR", "Different",
        "XOR (exclusive or) outputs 1 when the inputs are different.",
        ("a", "b"), ("out",), lambda a, b: (a ^ b,), 4,
        "XOR is (a OR b) AND NOT (a AND b). To reach 4 gates, compute n = NAND(a, b) once and reuse it.",
        "XOR is the 'sum' bit of binary addition: 0+1 = 1, 1+1 = 0 (carry 1). You'll need it soon.",
    ),
    Level(
        5, "MUX", "Choose",
        "A multiplexer picks one of two inputs. When sel is 0, out = a. When sel is 1, out = b.",
        ("sel", "a", "b"), ("out",), lambda sel, a, b: (b if sel else a,), 4,
        "Let a through only when sel is 0, let b through only when sel is 1, then combine the two with OR.",
        "CPUs use multiplexers everywhere. For example, choosing whether the next instruction comes from PC + 1 or from a jump.",
    ),
    Level(
        6, "HALFADD", "One plus one",
        "Add two bits. sum is the right-hand digit of a + b, and carry is the digit that moves left.\n"
        "0+0 = 00, 0+1 = 01, 1+0 = 01, 1+1 = 10.",
        ("a", "b"), ("sum", "carry"), lambda a, b: (a ^ b, a & b), 5,
        "Look at the sum column: it's a part you've built. Look at the carry column: so is that.\n"
        "Write two outputs on two lines, e.g.  sum = ...  and  carry = ...",
        "This is a half adder. It can add two bits, but not a carry coming in from the column to its right.",
    ),
    Level(
        7, "FULLADD", "Carry the one",
        "Add three bits: a, b, and a carry coming in from the column to the right (cin).\n"
        "sum is the right-hand digit, cout is the carry going out to the left.",
        ("a", "b", "cin"), ("sum", "cout"),
        lambda a, b, cin: ((a + b + cin) & 1, (a + b + cin) >> 1), 9,
        "Use two half adders: first add a and b, then add cin to that sum. A carry can come from either\n"
        "half adder, so combine the two carries with OR.  Tip: two outputs at once, e.g.  s1, c1 = HALFADD(a, b)",
        "This full adder is exactly what you do on paper when you add a column and carry the one.",
    ),
    Level(
        8, "ADD4", "Four-bit adder",
        "Add two 4-bit numbers: a3 a2 a1 a0 plus b3 b2 b1 b0. The answer is s3 s2 s1 s0, and\n"
        "carry is 1 if the answer is too big for 4 bits. Example: 0111 + 0101 = 1100 (7 + 5 = 12).",
        ("a3", "a2", "a1", "a0", "b3", "b2", "b1", "b0"), ("s3", "s2", "s1", "s0", "carry"),
        _add4, 32,
        "Start at the right with a0 + b0 (nothing carries in, so a half adder is enough). Pass each\n"
        "carry into a full adder for the next column to the left. This chain is called a ripple-carry adder.",
        "You built an adder from nothing but NAND gates. This is the circuit inside the ALU of a real CPU,\n"
        "including the one in Tiny CPU Bench, where ADD 7 + 5 runs through this exact chain.",
        goal_summary="s3 s2 s1 s0 = a3 a2 a1 a0 + b3 b2 b1 b0, with carry = 1 if the total is 16 or more",
    ),
)


def find_level(key: str) -> Level:
    """Finds a level by number ('3') or part name ('or')."""
    k = str(key).strip().upper()
    for lv in LEVELS:
        if k == str(lv.number) or k == lv.part_name:
            return lv
    raise KeyError(f"No level '{key}'. Use a number from 1 to {len(LEVELS)} or a part name like XOR.")


def goal_table(level: Level):
    """The correct truth table as (input bits, output bits) rows."""
    import itertools
    return [(bits, tuple(level.goal(*bits))) for bits in itertools.product((0, 1), repeat=len(level.inputs))]
