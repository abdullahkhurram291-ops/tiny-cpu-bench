"""The circuit engine: read a circuit written as text, check it, and work out its outputs.

A circuit is written one line per part, for example:

    n = NAND(a, b)        # a NAND gate with inputs a and b, output wire n
    out = NAND(n, n)      # feed n into both inputs of a second NAND
    s, c = HALFADD(a, b)  # parts with two outputs give two wires
    x = a                 # a plain wire: x carries the same value as a

`0` and `1` can be used anywhere a wire is expected.
"""

from __future__ import annotations

import itertools
import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

Bits = Tuple[int, ...]


class CircuitError(Exception):
    """A problem with a circuit, with the line number when there is one."""

    def __init__(self, message: str, line: Optional[int] = None):
        self.message = message
        self.line = line
        super().__init__(f"Line {line}: {message}" if line else message)


# --------------------------------------------------------------------------- parts


@dataclass(frozen=True)
class Part:
    """Something you can place in a circuit: NAND, or any circuit you built earlier."""

    name: str
    inputs: Tuple[str, ...]
    outputs: Tuple[str, ...]
    nand_count: int                      # how many NAND gates it is made of
    run: Callable[[Bits], Bits]          # input bits in order -> output bits in order


def _nand(bits: Bits) -> Bits:
    a, b = bits
    return (0 if (a and b) else 1,)


NAND = Part(name="NAND", inputs=("a", "b"), outputs=("out",), nand_count=1, run=_nand)


# --------------------------------------------------------------------------- parsing

NAME = r"[A-Za-z_][A-Za-z0-9_]*"
_LINE = re.compile(rf"^\s*({NAME}(?:\s*,\s*{NAME})*)\s*=\s*(.+?)\s*$")
_CALL = re.compile(rf"^({NAME})\s*\((.*)\)$")
_NAME_ONLY = re.compile(rf"^{NAME}$")
CONSTANTS = ("0", "1")


@dataclass(frozen=True)
class Statement:
    """One line of a circuit, after reading it."""

    line: int
    targets: Tuple[str, ...]   # wires on the left of `=`
    part: Optional[str]        # part name in capitals, or None for a plain wire `x = a`
    args: Tuple[str, ...]      # wires (or 0/1) fed into the part


def _check_arg(arg: str, line: int) -> str:
    if arg in CONSTANTS or _NAME_ONLY.match(arg):
        return arg
    if arg == "":
        raise CircuitError("there is an empty input between commas", line)
    if len(arg.split()) > 1:
        raise CircuitError(f"'{arg}' looks like two names. Did you forget a comma between them?", line)
    raise CircuitError(f"'{arg}' is not a wire name. Names use letters, digits and _, and can't start with a digit", line)


def parse_line(text: str, line: int = 1) -> Optional[Statement]:
    """Reads one line. Returns None for blank lines and comments."""
    text = text.split("#", 1)[0].strip()
    if not text:
        return None
    m = _LINE.match(text)
    if not m:
        if "=" not in text:
            raise CircuitError("every line needs an `=`, like  x = NAND(a, b)", line)
        raise CircuitError("the left side of `=` must be wire names separated by commas", line)
    targets = tuple(t.strip() for t in m.group(1).split(","))
    rhs = m.group(2)

    call = _CALL.match(rhs)
    if call:
        args_text = call.group(2).strip()
        if not args_text:
            raise CircuitError(f"{call.group(1)}() needs its inputs inside the brackets", line)
        args = tuple(_check_arg(a.strip(), line) for a in args_text.split(","))
        return Statement(line, targets, call.group(1).upper(), args)

    if rhs in CONSTANTS or _NAME_ONLY.match(rhs):
        if len(targets) != 1:
            raise CircuitError("a plain wire connects one name to one other name", line)
        return Statement(line, targets, None, (rhs,))

    raise CircuitError(f"can't read '{rhs}'. Expected a part like NAND(a, b) or a single wire name", line)


def parse(source: str) -> List[Statement]:
    statements = []
    for number, text in enumerate(source.splitlines(), start=1):
        st = parse_line(text, number)
        if st is not None:
            statements.append(st)
    return statements


# --------------------------------------------------------------------------- circuit


class Circuit:
    """A checked circuit that can be evaluated.

    inputs / outputs: the wire names the level asks for. Leave them as None in the sandbox,
    where any name that is used but never defined becomes an input, and any defined name
    that nothing else uses becomes an output.

    parts: the parts this circuit may use, by name.
    locked: optional explanations for parts that exist but can't be used yet.
    """

    MAX_INPUTS = 12

    def __init__(
        self,
        source: str,
        parts: Dict[str, Part],
        inputs: Optional[Sequence[str]] = None,
        outputs: Optional[Sequence[str]] = None,
        locked: Optional[Dict[str, str]] = None,
    ):
        self.source = source
        self.parts = parts
        self.statements = parse(source)
        if not self.statements:
            raise CircuitError("the circuit is empty. Add a line like  out = NAND(a, b)")

        locked = locked or {}
        self.defined_by: Dict[str, Statement] = {}

        # 1. Every part must exist and get the right number of wires.
        for st in self.statements:
            if st.part is None:
                continue
            if st.part not in parts:
                if st.part in locked:
                    raise CircuitError(locked[st.part], st.line)
                available = ", ".join(sorted(parts))
                raise CircuitError(f"there is no part called {st.part}. You can use: {available}", st.line)
            part = parts[st.part]
            if len(st.args) != len(part.inputs):
                raise CircuitError(
                    f"{part.name} takes {len(part.inputs)} input(s) ({', '.join(part.inputs)}) but got {len(st.args)}",
                    st.line)
            if len(st.targets) != len(part.outputs):
                names = ", ".join(part.outputs)
                raise CircuitError(
                    f"{part.name} gives {len(part.outputs)} output(s) ({names}), so put {len(part.outputs)} name(s) before `=`",
                    st.line)

        # 2. Each wire is defined once, and never on top of an input or a constant.
        given_inputs = tuple(inputs) if inputs is not None else ()
        for st in self.statements:
            for t in st.targets:
                if t in given_inputs:
                    raise CircuitError(f"'{t}' is an input, so it can't be given a new value", st.line)
                if t in self.defined_by:
                    first = self.defined_by[t].line
                    raise CircuitError(f"'{t}' was already defined on line {first}. Each wire can only have one source", st.line)
                self.defined_by[t] = st

        # 3. Work out the inputs and outputs.
        if inputs is not None:
            self.inputs = given_inputs
            for st in self.statements:
                for a in st.args:
                    if a not in CONSTANTS and a not in self.defined_by and a not in self.inputs:
                        raise CircuitError(
                            f"'{a}' is not an input ({', '.join(self.inputs)}) and is never defined", st.line)
        else:
            seen: List[str] = []
            for st in self.statements:
                for a in st.args:
                    if a not in CONSTANTS and a not in self.defined_by and a not in seen:
                        seen.append(a)
            self.inputs = tuple(seen)

        if outputs is not None:
            self.outputs = tuple(outputs)
            missing = [o for o in self.outputs if o not in self.defined_by]
            if missing:
                raise CircuitError(f"the output {', '.join(missing)} is never defined. Add a line like  {missing[0]} = ...")
        else:
            used = {a for st in self.statements for a in st.args}
            self.outputs = tuple(t for st in self.statements for t in st.targets if t not in used)

        if len(self.inputs) > self.MAX_INPUTS:
            raise CircuitError(f"too many inputs ({len(self.inputs)}). The limit is {self.MAX_INPUTS}")

        # 4. No loops: a wire can't depend on itself.
        self._check_for_loops()

    def _check_for_loops(self) -> None:
        DONE, VISITING = 2, 1
        state: Dict[str, int] = {}

        def visit(name: str, path: List[str]) -> None:
            if name not in self.defined_by or state.get(name) == DONE:
                return
            if state.get(name) == VISITING:
                loop = " -> ".join(path[path.index(name):] + [name])
                raise CircuitError(f"this creates a loop ({loop}). A wire can't depend on itself",
                                   self.defined_by[name].line)
            state[name] = VISITING
            for arg in self.defined_by[name].args:
                visit(arg, path + [name])
            state[name] = DONE

        for name in self.defined_by:
            visit(name, [])

    # ------------------------------------------------------------------ results

    @property
    def nand_count(self) -> int:
        """Total NAND gates, counting every gate inside the parts you used."""
        return sum(self.parts[st.part].nand_count for st in self.statements if st.part)

    def evaluate(self, values: Dict[str, int]) -> Dict[str, int]:
        """Works out the outputs for one set of input values, e.g. {'a': 1, 'b': 0}."""
        for name in self.inputs:
            if values.get(name) not in (0, 1):
                raise CircuitError(f"input '{name}' needs a value of 0 or 1")
        known: Dict[str, int] = {"0": 0, "1": 1}
        known.update({k: values[k] for k in self.inputs})

        def value_of(name: str) -> int:
            # Recursion: to know this wire, first find the wires feeding it.
            if name in known:
                return known[name]
            st = self.defined_by[name]
            arg_values = tuple(value_of(a) for a in st.args)
            results = arg_values if st.part is None else self.parts[st.part].run(arg_values)
            for target, v in zip(st.targets, results):
                known[target] = v
            return known[name]

        return {o: value_of(o) for o in self.outputs}

    def run_bits(self, bits: Bits) -> Bits:
        result = self.evaluate(dict(zip(self.inputs, bits)))
        return tuple(result[o] for o in self.outputs)

    def truth_table(self) -> List[Tuple[Bits, Bits]]:
        """Every input combination (00, 01, 10, 11, ...) with its outputs."""
        return [(bits, self.run_bits(bits)) for bits in itertools.product((0, 1), repeat=len(self.inputs))]

    def as_part(self, name: str) -> Part:
        """Packs this circuit up as a new part that later circuits can use."""
        return Part(name=name, inputs=self.inputs, outputs=self.outputs,
                    nand_count=self.nand_count, run=self.run_bits)
