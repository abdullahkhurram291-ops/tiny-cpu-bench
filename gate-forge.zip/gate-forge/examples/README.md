# Sandbox examples

Run any of these with:

```bash
python -m gate_forge sandbox examples/majority.txt
```

Write your own: any name you use but never define is an input, and any wire that nothing else uses is an output. You can use NAND plus every part you've unlocked in the game.
