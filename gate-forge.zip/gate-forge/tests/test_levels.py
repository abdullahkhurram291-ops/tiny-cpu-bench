import io
import tempfile
import unittest
from pathlib import Path

from gate_forge.game import main
from gate_forge.levels import LEVELS, find_level, goal_table
from gate_forge.progress import Progress, check

SOLUTIONS = Path(__file__).parent / "solutions"


def solution(level):
    return (SOLUTIONS / f"{level.part_name.lower()}.txt").read_text(encoding="utf-8")


class TempSave(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.save = Path(self.tmp.name) / "save.json"

    def tearDown(self):
        self.tmp.cleanup()


class TestLevels(unittest.TestCase):
    def test_numbered_in_order(self):
        self.assertEqual([lv.number for lv in LEVELS], list(range(1, len(LEVELS) + 1)))

    def test_find_level(self):
        self.assertEqual(find_level("4").part_name, "XOR")
        self.assertEqual(find_level("xor").number, 4)
        with self.assertRaises(KeyError):
            find_level("99")

    def test_goals_have_the_right_shape(self):
        for lv in LEVELS:
            rows = goal_table(lv)
            self.assertEqual(len(rows), 2 ** len(lv.inputs), lv.part_name)
            for _, out in rows:
                self.assertEqual(len(out), len(lv.outputs), lv.part_name)
                self.assertTrue(all(b in (0, 1) for b in out), lv.part_name)

    def test_four_bit_adder_goal(self):
        lv = find_level("ADD4")
        self.assertEqual(lv.goal(0, 1, 1, 1, 0, 1, 0, 1), (1, 1, 0, 0, 0))  # 7 + 5 = 12
        self.assertEqual(lv.goal(1, 1, 1, 1, 0, 0, 0, 1), (0, 0, 0, 0, 1))  # 15 + 1 = 16


class TestReferenceSolutions(unittest.TestCase):
    def test_every_level_can_be_solved_in_order_and_hits_the_target(self):
        unlocked = {}
        for lv in LEVELS:
            with self.subTest(level=lv.part_name):
                r = check(lv, solution(lv), unlocked)
                self.assertIsNone(r.error, r.error)
                self.assertTrue(r.passed)
                self.assertEqual(r.nand_count, lv.target)
                unlocked[lv.part_name] = r.circuit.as_part(lv.part_name)

    def test_wrong_circuit_reports_failing_rows(self):
        r = check(find_level("XOR"), "n = NAND(a, b)\nna = NAND(a, a)\nnb = NAND(b, b)\nout = NAND(na, nb)", {})
        self.assertFalse(r.passed)
        self.assertEqual([row[0] for row in r.wrong_rows], [(1, 1)])

    def test_cannot_use_the_part_you_are_building(self):
        r = check(find_level("AND"), "out = AND(a, b)", {})
        self.assertIn("building AND", str(r.error))

    def test_later_parts_are_locked(self):
        r = check(find_level("AND"), "out = XOR(a, b)", {})
        self.assertIn("Solve level 4", str(r.error))

    def test_bigger_solution_passes_without_a_star(self):
        r = check(find_level("NOT"), "x = NAND(a, a)\ny = NAND(x, x)\nout = NAND(y, y)", {})
        self.assertTrue(r.passed)
        self.assertFalse(r.star)
        self.assertEqual(r.nand_count, 3)


class TestProgress(TempSave):
    def test_saves_and_reloads(self):
        p = Progress(self.save)
        for lv in LEVELS[:3]:
            self.assertTrue(p.record(lv, solution(lv)).passed)
        again = Progress(self.save)
        self.assertEqual(set(again.unlocked), {"NOT", "AND", "OR"})
        self.assertTrue(again.is_open(find_level("XOR")))
        self.assertFalse(again.is_open(find_level("MUX")))

    def test_failed_attempts_are_not_saved(self):
        p = Progress(self.save)
        p.record(find_level("NOT"), "out = a")
        self.assertFalse(self.save.exists())

    def test_damaged_save_file_starts_fresh(self):
        self.save.write_text("{not json", encoding="utf-8")
        p = Progress(self.save)
        self.assertEqual(p.unlocked, {})

    def test_reset(self):
        p = Progress(self.save)
        p.record(find_level("NOT"), solution(find_level("NOT")))
        p.reset()
        self.assertEqual(Progress(self.save).unlocked, {})


class TestCommandLine(TempSave):
    def run_cli(self, *args, inputs=()):
        out = io.StringIO()
        feed = iter(inputs)

        def fake_input(prompt):
            out.write(prompt)
            try:
                return next(feed)
            except StopIteration:
                raise EOFError

        code = main(["--save", str(self.save), *args], out=out, input_fn=fake_input)
        return code, out.getvalue()

    def test_check_command(self):
        code, text = self.run_cli("check", "1", str(SOLUTIONS / "not.txt"))
        self.assertEqual(code, 0)
        self.assertIn("Solved", text)
        code, text = self.run_cli("check", "3", str(SOLUTIONS / "or.txt"))
        self.assertEqual(code, 1)
        self.assertIn("locked", text)

    def test_check_missing_file(self):
        code, text = self.run_cli("check", "1", "no_such_file.txt")
        self.assertEqual(code, 2)
        self.assertIn("Couldn't open", text)

    def test_sandbox(self):
        f = Path(self.tmp.name) / "c.txt"
        f.write_text("out = NAND(p, q)\n", encoding="utf-8")
        code, text = self.run_cli("sandbox", str(f))
        self.assertEqual(code, 0)
        self.assertIn("NAND gates: 1", text)

    def test_reset_needs_confirmation(self):
        self.run_cli("check", "1", str(SOLUTIONS / "not.txt"))
        code, _ = self.run_cli("reset")
        self.assertEqual(code, 1)
        self.assertTrue(self.save.exists())
        code, _ = self.run_cli("reset", "--yes")
        self.assertEqual(code, 0)
        self.assertFalse(self.save.exists())

    def test_interactive_play_through_two_levels(self):
        code, text = self.run_cli(inputs=[
            "", "out = NAND(a, a)", ":test",                       # level 1 (Enter picks it)
            "", ":hint", "n = NAND(a, b)", "out = NOT(n)", ":test",  # level 2
            "q",
        ])
        self.assertEqual(code, 0)
        self.assertEqual(text.count("Solved!"), 2)
        self.assertIn("put it after a NAND", text)
        self.assertEqual(set(Progress(self.save).unlocked), {"NOT", "AND"})

    def test_interactive_editing_commands(self):
        code, text = self.run_cli(inputs=[
            "1", "x = NAND(a a)", "x = NAND(a, a)", "y = x", ":show", ":del 2", ":undo", ":undo",
            ":wat", ":back", "q",
        ])
        self.assertIn("forget a comma", text)
        self.assertIn("Removed line 2: y = x", text)
        self.assertIn("Nothing to undo", text)
        self.assertIn("Unknown command", text)

    def test_locked_level_from_menu(self):
        _, text = self.run_cli(inputs=["5", "q"])
        self.assertIn("Level 5 is locked", text)

    def test_ctrl_d_exits_cleanly(self):
        code, _ = self.run_cli(inputs=[])
        self.assertEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
