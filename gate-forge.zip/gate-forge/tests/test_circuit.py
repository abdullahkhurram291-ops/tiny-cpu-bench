import unittest

from gate_forge.circuit import NAND, Circuit, CircuitError, parse_line

PARTS = {"NAND": NAND}


def table(source, inputs=None, outputs=None, parts=PARTS):
    c = Circuit(source, parts, inputs, outputs)
    return [out for _, out in c.truth_table()]


class TestParsing(unittest.TestCase):
    def test_reads_a_gate(self):
        st = parse_line("n = NAND(a, b)", 3)
        self.assertEqual(st.targets, ("n",))
        self.assertEqual(st.part, "NAND")
        self.assertEqual(st.args, ("a", "b"))
        self.assertEqual(st.line, 3)

    def test_part_names_ignore_case(self):
        self.assertEqual(parse_line("n = nand(a, b)").part, "NAND")

    def test_two_outputs_and_plain_wires(self):
        self.assertEqual(parse_line("s, c = HALFADD(a, b)").targets, ("s", "c"))
        st = parse_line("x = a")
        self.assertIsNone(st.part)
        self.assertEqual(st.args, ("a",))

    def test_comments_and_blank_lines(self):
        self.assertIsNone(parse_line("   "))
        self.assertIsNone(parse_line("# just a note"))
        self.assertEqual(parse_line("n = NAND(a, b)  # note").args, ("a", "b"))

    def test_constants(self):
        self.assertEqual(parse_line("n = NAND(a, 1)").args, ("a", "1"))

    def test_helpful_syntax_errors(self):
        cases = {
            "NAND(a, b)": "needs an `=`",
            "n = NAND(a b)": "forget a comma",
            "n = NAND(a, , b)": "empty input",
            "n = NAND()": "needs its inputs",
            "2x = NAND(a, b)": "left side",
            "n = a + b": "can't read",
            "n = NAND(a, 2b)": "not a wire name",
        }
        for text, words in cases.items():
            with self.subTest(text=text):
                with self.assertRaises(CircuitError) as ctx:
                    parse_line(text)
                self.assertIn(words, str(ctx.exception))


class TestCircuitChecks(unittest.TestCase):
    def assertCircuitError(self, source, words, inputs=("a", "b"), outputs=("out",)):
        with self.assertRaises(CircuitError) as ctx:
            Circuit(source, PARTS, inputs, outputs)
        self.assertIn(words, str(ctx.exception))
        return ctx.exception

    def test_empty(self):
        self.assertCircuitError("# nothing\n", "empty")

    def test_unknown_part(self):
        self.assertCircuitError("out = AND(a, b)", "no part called AND")

    def test_locked_part_message(self):
        with self.assertRaises(CircuitError) as ctx:
            Circuit("out = XOR(a, b)", PARTS, ("a", "b"), ("out",), locked={"XOR": "XOR is locked"})
        self.assertIn("XOR is locked", str(ctx.exception))

    def test_wrong_number_of_inputs_or_outputs(self):
        self.assertCircuitError("out = NAND(a)", "takes 2 input")
        self.assertCircuitError("out, x = NAND(a, b)", "gives 1 output")

    def test_defined_twice(self):
        err = self.assertCircuitError("out = NAND(a, b)\nout = NAND(a, a)", "already defined on line 1")
        self.assertEqual(err.line, 2)

    def test_cannot_overwrite_input(self):
        self.assertCircuitError("a = NAND(a, b)\nout = a", "is an input")

    def test_undefined_wire(self):
        self.assertCircuitError("out = NAND(a, c)", "'c' is not an input")

    def test_missing_output(self):
        self.assertCircuitError("x = NAND(a, b)", "output out is never defined")

    def test_loops_are_found(self):
        err = self.assertCircuitError("x = NAND(a, y)\ny = NAND(x, b)\nout = x", "loop")
        self.assertIn("x -> y -> x", str(err))

    def test_line_numbers_skip_comments(self):
        err = self.assertCircuitError("# first\n\nout = NAND(a, q)", "'q'")
        self.assertEqual(err.line, 3)


class TestEvaluation(unittest.TestCase):
    def test_nand_truth_table(self):
        self.assertEqual(table("out = NAND(a, b)", ("a", "b"), ("out",)), [(1,), (1,), (1,), (0,)])

    def test_rows_are_in_counting_order(self):
        c = Circuit("out = NAND(a, b)", PARTS, ("a", "b"), ("out",))
        self.assertEqual([bits for bits, _ in c.truth_table()], [(0, 0), (0, 1), (1, 0), (1, 1)])

    def test_order_of_lines_does_not_matter(self):
        src = "out = NAND(x, y)\ny = NAND(b, n)\nx = NAND(a, n)\nn = NAND(a, b)"
        self.assertEqual(table(src, ("a", "b"), ("out",)), [(0,), (1,), (1,), (0,)])  # XOR

    def test_constants_and_plain_wires(self):
        self.assertEqual(table("out = NAND(a, 1)", ("a",), ("out",)), [(1,), (0,)])
        self.assertEqual(table("out = a", ("a",), ("out",)), [(0,), (1,)])
        self.assertEqual(table("out = 1", ("a",), ("out",)), [(1,), (1,)])

    def test_nand_count_counts_every_gate(self):
        c = Circuit("n = NAND(a, b)\nout = NAND(n, n)\nunused = NAND(a, a)", PARTS, ("a", "b"), ("out",))
        self.assertEqual(c.nand_count, 3)

    def test_evaluate_rejects_bad_inputs(self):
        c = Circuit("out = NAND(a, b)", PARTS, ("a", "b"), ("out",))
        with self.assertRaises(CircuitError):
            c.evaluate({"a": 1})
        with self.assertRaises(CircuitError):
            c.evaluate({"a": 1, "b": 2})


class TestPartsFromCircuits(unittest.TestCase):
    def test_a_circuit_becomes_a_part(self):
        not_part = Circuit("out = NAND(a, a)", PARTS, ("a",), ("out",)).as_part("NOT")
        self.assertEqual(not_part.run((0,)), (1,))
        self.assertEqual(not_part.nand_count, 1)
        and_c = Circuit("n = NAND(a, b)\nout = NOT(n)", {**PARTS, "NOT": not_part}, ("a", "b"), ("out",))
        self.assertEqual([o for _, o in and_c.truth_table()], [(0,), (0,), (0,), (1,)])
        self.assertEqual(and_c.nand_count, 2, "NAND count includes the gates inside NOT")

    def test_parts_with_two_outputs(self):
        ha = Circuit("n = NAND(a, b)\nx = NAND(a, n)\ny = NAND(b, n)\ns = NAND(x, y)\nc = NAND(n, n)",
                     PARTS, ("a", "b"), ("s", "c")).as_part("HALFADD")
        c = Circuit("s, c = HALFADD(a, b)", {**PARTS, "HALFADD": ha}, ("a", "b"), ("s", "c"))
        self.assertEqual([o for _, o in c.truth_table()], [(0, 0), (1, 0), (1, 0), (0, 1)])


class TestSandboxMode(unittest.TestCase):
    def test_inputs_and_outputs_are_worked_out(self):
        c = Circuit("n = NAND(p, q)\nr = NAND(n, n)", PARTS)
        self.assertEqual(c.inputs, ("p", "q"))
        self.assertEqual(c.outputs, ("r",))

    def test_too_many_inputs(self):
        src = "\n".join(f"x{i} = NAND(i{i}, j{i})" for i in range(7))
        with self.assertRaises(CircuitError):
            Circuit(src, PARTS)


if __name__ == "__main__":
    unittest.main()
